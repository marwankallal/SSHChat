/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sshchat;

/**
 *
 * @author marwankallal
 */

// THIS IS CLIENT CODE
import java.util.Scanner;
public class SSHChat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("1: Pick a host and only run client"
                    + "\n2: Run a server"
                    + "\n3: Run a server and client simultaneously (usually used for private chats)"
                    + "\nPlease enter your selection: ");
        
       Scanner s = new Scanner(System.in);
       int c = s.nextInt();
       int port;
       String host;
        switch(c){
            case 1:
                System.out.print("Please specify the host: ");
                host = "127.0.0.1";
                System.out.print("\nPlease specify the port: ");
                port = s.nextInt();
                Client client = new Client(host, port);
                break;
            case 2:
                //make server
                System.out.print("Please specify the port: ");
                port = s.nextInt();
                Server server = new Server(port);
                break;
            case 3:
                //make both
                System.out.print("Please specify the port: ");
                port = s.nextInt();
                Server sserver = new Server(port);
                Client sclient = new Client("localhost", port);
                break;
            default:
                System.out.print("That is not a valid input. Please try again.");
                break;
        }
       


        
        
        // GUI STUFF
        
    }
}
