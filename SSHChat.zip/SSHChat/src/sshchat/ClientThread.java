/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sshchat;

/**
 *
 * @author marwankallal
 */
import java.net.*;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.io.*;
import javax.net.ServerSocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
public class ClientThread extends Thread
{
    SSLSocketFactory factory;
    SSLSocket socket;
    Client client;
    DataInputStream in;
    
    public ClientThread(Client c, SSLSocket s)
    {
        client = c;
        socket = s;
        open();
        start();
    }
    
    public void open()
    {
        try
        {
            in = new DataInputStream(socket.getInputStream());
        }
        catch(IOException e)
        {
            System.out.println("Input dont work");
            client.stop();
        }
    }
    
    public void close()
    {
        try
        {
            if(in != null)
            {
                in.close();
            }
        }
        catch(IOException e)
        {
            System.out.println("Error on closing");
        }
    }
    
    public void run()
    {
        while(true)
        {
            try
            {
                System.out.println(in.readUTF());
            }
            catch(IOException e)
            {
                System.out.println("read error" + e);
                client.stop();
            }
        }
    }
}
