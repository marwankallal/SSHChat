/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sshchat;

/**
 *
 * @author marwankallal
 */
import java.net.*;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.io.*;
import javax.net.ServerSocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.*;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
public class Server implements Runnable{
    ServerThread clist[] = new ServerThread[100];
    SSLServerSocketFactory sfactory;
    SSLServerSocket server;
    Thread thread;
    int pop;
    
    public Server(int p)
    {
        try
        {
            char[] passphrase = "passphrase".toCharArray();

            String keypath = "key";
            //String trustpath =
            // First initialize the key and trust material.
            KeyStore ksKeys = KeyStore.getInstance("JKS");
            ksKeys.load(new FileInputStream(new File(keypath)), passphrase);
            KeyStore ksTrust = KeyStore.getInstance("JKS");
            ksTrust.load(new FileInputStream(new File(keypath)), passphrase);

            // KeyManager's decide which key material to use.
            KeyManagerFactory kmf =
                KeyManagerFactory.getInstance("SunX509");
            kmf.init(ksKeys, passphrase);

            // TrustManager's decide whether to allow connections.
            TrustManagerFactory tmf =
                TrustManagerFactory.getInstance("SunX509");
            tmf.init(ksTrust);

            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(
                kmf.getKeyManagers(), tmf.getTrustManagers(), null);
            sfactory = ctx.getServerSocketFactory();
            server = (SSLServerSocket) sfactory.createServerSocket(p);
            start();
        }
        catch(IOException e)
        {
            System.out.println("s No can connect to port");
        }
        catch(KeyStoreException e)
        {
            System.err.println("s Keystore exception");
        }
        catch(NoSuchAlgorithmException e)
        {
            System.out.println("s algo problem");
        }
        catch(KeyManagementException e)
        {
            System.out.println("s KeyManagemtn prob");
        }
        catch(CertificateException e)
        {
            System.out.println("s certexpet prob");
        }
        catch(UnrecoverableKeyException e)
        {
            System.out.println("s unrecoverable key prob");
        }
    }
    
    public void run()
    {
        while(thread != null)
        {
            try
            {
                addThread((SSLSocket) server.accept());
                System.out.println("New Connection Recieved");
            }
            catch(IOException e)
            {
                System.out.println("No can connect to port ... sorry: " + e);
               
            }
        }
    }
    
    private int getClient(int n)
    {
        for(int i = 0; i < pop; i++)
        {
            if(clist[i].getID() == n)
            {
                return i;
            }
        }
        return -1;
    }
    
    public synchronized void remove(int n)
    {
        int pos = getClient(n);
        if(pos >= 0)
        {
            ServerThread quitthread = clist[pos];
            System.out.println("Getting rid of client " + n);
            pop--;
            try
            {
                quitthread.close();
            }
            catch(IOException e)
            {
                System.out.println("Can't close buddy");
            }
            stop();
            clist[pos] = null;
        }
    }
    
    private void addThread(SSLSocket socket)
    {
        if(pop < clist.length)
        {
            int pos = 0;
            System.out.println("New connection " + socket);
            for(ServerThread server : clist)
            {
                if(server == null)
                {
                    server = new ServerThread(this, socket);
                    try
                    {
                        server.open();
                        start();
                        pos++;
                        break;
                    }
                    catch(IOException e)
                    {
                        System.out.println("No can open thread");
                    }
                }
                pos++;
            }
        }
        else
        {
            System.out.println("Sorry, server full at " + pop);
        }
    }
    
    public void start()
    {  
        if (thread == null)
        {  
            thread = new Thread(this); 
            thread.start();
        }
    }
    public void stop()
    {
        if (thread != null)
        {  
            try
            {
                thread.join();
            }
            catch (InterruptedException e)
            {
                System.out.println("Error on close");
            }
            thread = null;
        }
    }
}
