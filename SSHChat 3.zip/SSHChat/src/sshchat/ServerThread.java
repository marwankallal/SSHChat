/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sshchat;

import java.net.*;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.io.*;
import javax.net.ServerSocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.*;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
/**
 *
 * @author marwankallal
 */
public class ServerThread extends Thread{
    Server server;
    SSLSocket socket;
    int ID = -1;
    DataInputStream in;
    DataOutputStream out;
    Thread thread;
    String handle;
    
    private final int MAX_GUEST = 10000;
    
    public ServerThread(Server serv, SSLSocket sslsock)
    {
        super();
        server = serv;
        socket = sslsock;
        ID = socket.getPort();
        handle = "Guest " + (int)(Math.random() * MAX_GUEST);
    }
    public void send (String str)
    {
        try
        {
            out.writeUTF(handle + ": " + str);
            out.flush();
            //System.out.println(str);
        }
        catch(IOException e)
        {
            System.out.println("Cant write");
            server.remove(ID);
            server.stop();
        }
    }
    public int getID()
    {
        return ID;
    }
    
    public void run()
    {
        // handle @ and disconnect
        System.out.println("## :D ServerThread running");
        while (true)
        {  
            try
            {  
                String str = in.readUTF();
                send(str);
                break;
                //System.out.println(str);
            }

            catch(IOException ioe)
            {  
                System.out.println("read broke");
            }

        }
    }
    
    public void open() throws IOException
    {
        //add new BufferedInputStream ?
        in = new DataInputStream((socket.getInputStream()));
        out = new DataOutputStream((socket.getOutputStream()));
        if (thread == null)
        {  
            thread = new Thread(this); 
            thread.run();
        }
    }
    
    public void close() throws IOException
    {
        if(socket != null && in != null && out != null)
        {
            socket.close();
            in.close();
            out.close();
        }
    }
        
}
